package com.aventureros.item;

import com.aventureros.entity.AdventurerClass;
import com.aventureros.entity.AdventurerEntity;
import com.aventureros.registry.ModEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Huevo de aventurero: de una clase concreta, o de una clase al azar si no se indica. */
public class AdventurerEggItem extends Item {
    @Nullable
    private final AdventurerClass adventurerClass;

    public AdventurerEggItem(@Nullable AdventurerClass adventurerClass, Properties properties) {
        super(properties);
        this.adventurerClass = adventurerClass;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel server)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        AdventurerEntity adventurer = ModEntities.ADVENTURER.get().create(server);
        if (adventurer == null) {
            return InteractionResult.FAIL;
        }
        if (this.adventurerClass != null) {
            adventurer.presetClass(this.adventurerClass);
        }
        adventurer.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, server.random.nextFloat() * 360.0F, 0.0F);
        adventurer.finalizeSpawn(server, server.getCurrentDifficultyAt(pos), MobSpawnType.SPAWN_EGG, null, null);
        server.addFreshEntity(adventurer);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
