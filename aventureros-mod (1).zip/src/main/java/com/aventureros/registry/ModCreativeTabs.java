package com.aventureros.registry;

import com.aventureros.AventurerosMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AventurerosMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("aventureros",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.aventureros"))
                    .icon(() -> new ItemStack(ModItems.RANDOM_EGG.get()))
                    .displayItems((parameters, output) ->
                            ModItems.ITEMS.getEntries().forEach(item -> output.accept(item.get())))
                    .build());
}
