package com.aventureros.registry;

import com.aventureros.AventurerosMod;
import com.aventureros.entity.AdventurerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AventurerosMod.MODID);

    public static final RegistryObject<EntityType<AdventurerEntity>> ADVENTURER = ENTITIES.register("aventurero",
            () -> EntityType.Builder.<AdventurerEntity>of(AdventurerEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.25F)
                    .clientTrackingRange(10)
                    .build("aventurero"));
}
