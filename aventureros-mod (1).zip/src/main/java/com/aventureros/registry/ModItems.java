package com.aventureros.registry;

import com.aventureros.AventurerosMod;
import com.aventureros.entity.AdventurerClass;
import com.aventureros.item.AdventurerEggItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AventurerosMod.MODID);

    /** Huevo de aventurero de clase aleatoria. */
    public static final RegistryObject<Item> RANDOM_EGG = ITEMS.register("aventurero_egg",
            () -> new AdventurerEggItem(null, new Item.Properties()));

    /** Un huevo por cada clase. */
    static {
        for (AdventurerClass cls : AdventurerClass.values()) {
            ITEMS.register(cls.id() + "_egg", () -> new AdventurerEggItem(cls, new Item.Properties()));
        }
    }
}
