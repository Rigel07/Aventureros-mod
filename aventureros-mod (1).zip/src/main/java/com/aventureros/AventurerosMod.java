package com.aventureros;

import com.aventureros.registry.ModCreativeTabs;
import com.aventureros.registry.ModEntities;
import com.aventureros.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AventurerosMod.MODID)
public class AventurerosMod {
    public static final String MODID = "aventureros";

    public AventurerosMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
