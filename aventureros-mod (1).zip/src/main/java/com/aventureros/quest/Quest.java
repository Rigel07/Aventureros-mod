package com.aventureros.quest;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

/** Una mision concreta: que hay que hacer, cuanto llevas y que se gana. */
public class Quest {
    public QuestType type = QuestType.FETCH;
    /** Item, mob o bloque (con # delante si es una etiqueta). Vacio para pescar. */
    public String target = "";
    public int need = 1;
    public int have = 0;
    public int tier = 1;
    public int classId = 0;
    public UUID giver = new UUID(0L, 0L);
    /** Nombre del aventurero en JSON de texto, para poder mostrarlo traducido. */
    public String giverNameJson = "";
    public int xp = 0;
    public List<ItemStack> rewards = new ArrayList<>();

    public Quest copy() {
        return fromNbt(this.toNbt());
    }

    public boolean isComplete() {
        return this.have >= this.need;
    }

    public MutableComponent giverName() {
        try {
            MutableComponent name = Component.Serializer.fromJson(this.giverNameJson);
            if (name != null) {
                return name;
            }
        } catch (RuntimeException ignored) {
            // nombre corrupto: usamos uno generico
        }
        return Component.translatable("quest.aventureros.someone");
    }

    // ------------------------------------------------------------ Texto

    /** "Trae 6 x Perla de Ender", "Derrota a 8 x Zombi", etc. */
    public Component describe() {
        return switch (this.type) {
            case FETCH -> Component.translatable("quest.aventureros.fetch", this.need, itemName(this.target));
            case KILL -> Component.translatable("quest.aventureros.kill", this.need, entityName(this.target));
            case MINE -> Component.translatable("quest.aventureros.mine", this.need, blockName(this.target));
            case FISH -> Component.translatable("quest.aventureros.fish", this.need);
        };
    }

    public Component describeWithProgress() {
        if (this.type == QuestType.FETCH) {
            return this.describe();
        }
        return Component.translatable("quest.aventureros.progress", this.describe(), this.have, this.need);
    }

    public Component describeRewards() {
        MutableComponent text = Component.empty();
        boolean first = true;
        for (ItemStack stack : this.rewards) {
            if (!first) {
                text.append(", ");
            }
            first = false;
            text.append(stack.getCount() + " x ").append(stack.getHoverName());
        }
        if (this.xp > 0) {
            if (!first) {
                text.append(", ");
            }
            text.append(Component.translatable("quest.aventureros.xp", this.xp));
        }
        return text;
    }

    public static Component itemName(String id) {
        Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
        return item == null ? Component.literal(id) : new ItemStack(item).getHoverName();
    }

    public static Component entityName(String id) {
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(id));
        return type == null ? Component.literal(id) : type.getDescription();
    }

    public static Component blockName(String id) {
        if (id.startsWith("#")) {
            String path = new ResourceLocation(id.substring(1)).getPath().replace('/', '_');
            return Component.translatable("quest.aventureros.tag." + path);
        }
        Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(id));
        return block == null ? Component.literal(id) : block.getName();
    }

    // ------------------------------------------------------------- NBT

    public CompoundTag toNbt() {
        CompoundTag tag = new CompoundTag();
        tag.putString("Type", this.type.name());
        tag.putString("Target", this.target);
        tag.putInt("Need", this.need);
        tag.putInt("Have", this.have);
        tag.putInt("Tier", this.tier);
        tag.putInt("Class", this.classId);
        tag.putUUID("Giver", this.giver);
        tag.putString("GiverName", this.giverNameJson);
        tag.putInt("Xp", this.xp);
        ListTag list = new ListTag();
        for (ItemStack stack : this.rewards) {
            list.add(stack.save(new CompoundTag()));
        }
        tag.put("Rewards", list);
        return tag;
    }

    public static Quest fromNbt(CompoundTag tag) {
        Quest quest = new Quest();
        try {
            quest.type = QuestType.valueOf(tag.getString("Type"));
        } catch (IllegalArgumentException error) {
            quest.type = QuestType.FETCH;
        }
        quest.target = tag.getString("Target");
        quest.need = Math.max(1, tag.getInt("Need"));
        quest.have = tag.getInt("Have");
        quest.tier = tag.getInt("Tier");
        quest.classId = tag.getInt("Class");
        if (tag.hasUUID("Giver")) {
            quest.giver = tag.getUUID("Giver");
        }
        quest.giverNameJson = tag.getString("GiverName");
        quest.xp = tag.getInt("Xp");
        ListTag list = tag.getList("Rewards", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            ItemStack stack = ItemStack.of(list.getCompound(i));
            if (!stack.isEmpty()) {
                quest.rewards.add(stack);
            }
        }
        return quest;
    }
}
