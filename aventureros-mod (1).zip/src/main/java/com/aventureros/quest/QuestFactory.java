package com.aventureros.quest;

import com.aventureros.entity.AdventurerClass;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.ForgeRegistries;

/** Genera las misiones y recompensas de cada tipo de aventurero. */
public final class QuestFactory {
    private QuestFactory() {}

    /** Plantilla de mision: tipo, objetivo, cantidad minima y maxima, dificultad (1 a 3). */
    private record Template(QuestType type, String target, int min, int max, int tier) {}

    private static Template fetch(String item, int min, int max, int tier) {
        return new Template(QuestType.FETCH, item, min, max, tier);
    }
    private static Template kill(String mob, int min, int max, int tier) {
        return new Template(QuestType.KILL, mob, min, max, tier);
    }
    private static Template mine(String block, int min, int max, int tier) {
        return new Template(QuestType.MINE, block, min, max, tier);
    }
    private static Template fish(int min, int max, int tier) {
        return new Template(QuestType.FISH, "", min, max, tier);
    }

    private static List<Template> templates(AdventurerClass cls) {
        return switch (cls) {
            case KNIGHT -> List.of(kill("minecraft:zombie", 6, 10, 1), kill("minecraft:skeleton", 4, 8, 2),
                    kill("minecraft:spider", 4, 6, 1), kill("minecraft:witch", 1, 2, 3));
            case WIZARD -> List.of(fetch("minecraft:amethyst_shard", 4, 8, 1), fetch("minecraft:lapis_lazuli", 8, 16, 1),
                    fetch("minecraft:ender_pearl", 1, 2, 3), kill("minecraft:witch", 1, 2, 3));
            case ARCHER -> List.of(kill("minecraft:skeleton", 5, 8, 2), kill("minecraft:creeper", 2, 4, 2),
                    fetch("minecraft:feather", 6, 12, 1), fetch("minecraft:arrow", 16, 32, 1));
            case ROGUE -> List.of(fetch("minecraft:gold_nugget", 12, 24, 1), fetch("minecraft:emerald", 2, 4, 2),
                    kill("minecraft:spider", 5, 8, 1));
            case CLERIC -> List.of(fetch("minecraft:bread", 6, 10, 1), fetch("minecraft:honey_bottle", 2, 3, 2),
                    kill("minecraft:zombie", 8, 12, 1), kill("minecraft:skeleton", 6, 10, 2));
            case BARD -> List.of(fetch("minecraft:feather", 8, 12, 1), fetch("minecraft:string", 8, 12, 1),
                    fetch("minecraft:honeycomb", 3, 5, 2), fetch("minecraft:glow_berries", 6, 10, 1));
            case EXPLORER -> List.of(fetch("minecraft:apple", 4, 6, 1), fetch("minecraft:glow_berries", 5, 10, 1),
                    fetch("minecraft:compass", 1, 1, 2), mine("#minecraft:logs", 12, 24, 1));
            case MINER -> List.of(mine("minecraft:stone", 32, 64, 1), mine("#forge:ores/coal", 8, 12, 1),
                    mine("#forge:ores/iron", 6, 10, 2), mine("#forge:ores/copper", 8, 14, 1),
                    mine("#forge:ores/gold", 4, 8, 3));
            case FISHER -> List.of(fish(3, 6, 1), fetch("minecraft:cod", 6, 10, 1),
                    fetch("minecraft:salmon", 4, 8, 2), fish(8, 12, 2));
            case PIRATE -> List.of(fetch("minecraft:gold_ingot", 6, 12, 2), fetch("minecraft:ink_sac", 4, 8, 1),
                    kill("minecraft:drowned", 4, 6, 2), fetch("minecraft:prismarine_shard", 4, 8, 2));
            case NINJA -> List.of(kill("minecraft:creeper", 2, 4, 2), kill("minecraft:spider", 5, 8, 1),
                    fetch("minecraft:string", 8, 16, 1), kill("minecraft:pillager", 2, 4, 3));
            case ALCHEMIST -> List.of(fetch("minecraft:glowstone_dust", 6, 12, 2), fetch("minecraft:spider_eye", 4, 8, 1),
                    fetch("minecraft:nether_wart", 6, 12, 2), fetch("minecraft:redstone", 10, 20, 1));
            case CHEF -> List.of(fetch("minecraft:wheat", 12, 20, 1), fetch("minecraft:egg", 6, 12, 1),
                    fetch("minecraft:sugar", 8, 16, 1), fetch("minecraft:cocoa_beans", 6, 10, 2));
            case FARMER -> List.of(fetch("minecraft:wheat", 16, 32, 1), fetch("minecraft:carrot", 12, 24, 1),
                    fetch("minecraft:potato", 12, 24, 1), fetch("minecraft:pumpkin", 3, 5, 2),
                    fetch("minecraft:melon_slice", 8, 16, 1));
        };
    }

    /** Recompensas comunes y raras: "item,min,max". "book" = libro encantado al azar. */
    private static String[] commonRewards(AdventurerClass cls) {
        return switch (cls) {
            case KNIGHT -> new String[]{"minecraft:iron_ingot,2,5", "minecraft:cooked_beef,4,8", "minecraft:arrow,8,16"};
            case WIZARD -> new String[]{"minecraft:lapis_lazuli,4,9", "minecraft:experience_bottle,2,4", "minecraft:amethyst_shard,3,6"};
            case ARCHER -> new String[]{"minecraft:arrow,16,32", "minecraft:feather,6,12", "minecraft:cooked_chicken,3,6"};
            case ROGUE -> new String[]{"minecraft:gold_nugget,8,16", "minecraft:emerald,1,3", "minecraft:string,6,12"};
            case CLERIC -> new String[]{"minecraft:golden_carrot,3,6", "minecraft:honey_bottle,1,2", "minecraft:experience_bottle,2,3"};
            case BARD -> new String[]{"minecraft:note_block,1,2", "minecraft:firework_rocket,3,6", "minecraft:cake,1,1"};
            case EXPLORER -> new String[]{"minecraft:map,1,1", "minecraft:compass,1,1", "minecraft:lead,1,2"};
            case MINER -> new String[]{"minecraft:coal,8,16", "minecraft:iron_ingot,3,6", "minecraft:copper_ingot,6,12"};
            case FISHER -> new String[]{"minecraft:cooked_salmon,4,8", "minecraft:cooked_cod,4,8", "minecraft:string,4,8"};
            case PIRATE -> new String[]{"minecraft:gold_ingot,3,6", "minecraft:emerald,2,4", "minecraft:compass,1,1"};
            case NINJA -> new String[]{"minecraft:iron_nugget,8,16", "minecraft:snowball,8,16", "minecraft:emerald,1,3"};
            case ALCHEMIST -> new String[]{"minecraft:glass_bottle,4,8", "minecraft:blaze_powder,2,4", "minecraft:experience_bottle,2,4"};
            case CHEF -> new String[]{"minecraft:cookie,8,16", "minecraft:pumpkin_pie,2,4", "minecraft:cake,1,1"};
            case FARMER -> new String[]{"minecraft:bone_meal,8,16", "minecraft:wheat_seeds,8,16", "minecraft:honeycomb,2,4"};
        };
    }

    private static String[] rareRewards(AdventurerClass cls) {
        return switch (cls) {
            case KNIGHT -> new String[]{"minecraft:diamond,1,2", "minecraft:shield,1,1", "minecraft:golden_apple,1,2", "book,1,1"};
            case WIZARD -> new String[]{"book,1,1", "minecraft:ender_pearl,2,3", "minecraft:experience_bottle,6,10"};
            case ARCHER -> new String[]{"minecraft:crossbow,1,1", "minecraft:spectral_arrow,16,24", "book,1,1"};
            case ROGUE -> new String[]{"minecraft:ender_pearl,2,3", "minecraft:diamond,1,1", "minecraft:name_tag,1,2"};
            case CLERIC -> new String[]{"minecraft:golden_apple,2,3", "book,1,1", "minecraft:totem_of_undying,1,1"};
            case BARD -> new String[]{"minecraft:music_disc_cat,1,1", "minecraft:music_disc_blocks,1,1", "minecraft:music_disc_chirp,1,1",
                    "minecraft:music_disc_mellohi,1,1", "minecraft:music_disc_wait,1,1"};
            case EXPLORER -> new String[]{"minecraft:saddle,1,1", "minecraft:name_tag,1,2", "minecraft:ender_eye,2,4"};
            case MINER -> new String[]{"minecraft:diamond,1,3", "minecraft:raw_gold,4,8", "book,1,1"};
            case FISHER -> new String[]{"minecraft:nautilus_shell,1,2", "minecraft:name_tag,1,2", "book,1,1"};
            case PIRATE -> new String[]{"minecraft:heart_of_the_sea,1,1", "minecraft:nautilus_shell,1,2", "minecraft:golden_apple,1,2"};
            case NINJA -> new String[]{"minecraft:ender_pearl,3,4", "minecraft:netherite_scrap,1,1", "book,1,1"};
            case ALCHEMIST -> new String[]{"minecraft:ghast_tear,1,2", "minecraft:brewing_stand,1,1", "minecraft:golden_carrot,6,10"};
            case CHEF -> new String[]{"minecraft:golden_carrot,6,10", "minecraft:golden_apple,1,1", "minecraft:cake,2,3"};
            case FARMER -> new String[]{"minecraft:diamond_hoe,1,1", "minecraft:golden_carrot,6,10", "minecraft:honeycomb,6,10"};
        };
    }

    private static final String[] BOOK_ENCHANTS = {
            "minecraft:sharpness,3", "minecraft:unbreaking,3", "minecraft:efficiency,3", "minecraft:mending,1",
            "minecraft:protection,3", "minecraft:power,3", "minecraft:looting,2", "minecraft:fortune,2",
            "minecraft:feather_falling,3", "minecraft:smite,3", "minecraft:fire_aspect,1", "minecraft:thorns,2"
    };

    // ---------------------------------------------------------- Generacion

    public static Quest generate(AdventurerClass cls, RandomSource random, java.util.UUID giver, Component giverName) {
        List<Template> list = templates(cls);
        Template template = list.get(random.nextInt(list.size()));
        Quest quest = new Quest();
        quest.type = template.type();
        quest.target = template.target();
        quest.need = template.min() + random.nextInt(template.max() - template.min() + 1);
        quest.tier = template.tier();
        quest.classId = cls.ordinal();
        quest.giver = giver;
        quest.giverNameJson = Component.Serializer.toJson(giverName);
        quest.xp = 8 * quest.tier + random.nextInt(8 * quest.tier + 1);
        quest.rewards = rewards(cls, quest.tier, random);
        return quest;
    }

    private static List<ItemStack> rewards(AdventurerClass cls, int tier, RandomSource random) {
        List<ItemStack> rewards = new ArrayList<>();
        // Siempre unas esmeraldas, mas cuanto mas dificil
        rewards.add(new ItemStack(Items.EMERALD, 1 + tier + random.nextInt(2 * tier + 1)));
        // Premio de la clase: raro si la mision es dificil
        boolean rare = tier >= 3 ? random.nextInt(100) < 70 : (tier == 2 && random.nextInt(100) < 25);
        String[] pool = rare ? rareRewards(cls) : commonRewards(cls);
        ItemStack main = parse(pool[random.nextInt(pool.length)], random);
        if (!main.isEmpty()) {
            rewards.add(main);
        }
        // Un extra comun en misiones medias y dificiles
        if (tier >= 2) {
            String[] extra = commonRewards(cls);
            ItemStack bonus = parse(extra[random.nextInt(extra.length)], random);
            if (!bonus.isEmpty()) {
                rewards.add(bonus);
            }
        }
        return rewards;
    }

    private static ItemStack parse(String spec, RandomSource random) {
        String[] parts = spec.split(",");
        if (parts[0].equals("book")) {
            String[] enchant = BOOK_ENCHANTS[random.nextInt(BOOK_ENCHANTS.length)].split(",");
            Enchantment enchantment = ForgeRegistries.ENCHANTMENTS.getValue(new ResourceLocation(enchant[0]));
            if (enchantment == null) {
                return ItemStack.EMPTY;
            }
            return EnchantedBookItem.createForEnchantment(new EnchantmentInstance(enchantment, Integer.parseInt(enchant[1])));
        }
        Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(parts[0]));
        if (item == null || item == Items.AIR) {
            return ItemStack.EMPTY;
        }
        int min = Integer.parseInt(parts[1]);
        int max = Integer.parseInt(parts[2]);
        return new ItemStack(item, min + random.nextInt(max - min + 1));
    }
}
