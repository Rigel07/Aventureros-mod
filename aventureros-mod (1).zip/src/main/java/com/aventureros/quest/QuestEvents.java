package com.aventureros.quest;

import com.aventureros.AventurerosMod;
import com.mojang.brigadier.context.CommandContext;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Cuenta el progreso de las misiones y ofrece el comando /aventureros. */
@Mod.EventBusSubscriber(modid = AventurerosMod.MODID)
public class QuestEvents {

    @SubscribeEvent
    public static void onKill(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        LivingEntity dead = event.getEntity();
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(dead.getType());
        if (key == null) {
            return;
        }
        advance(player, QuestType.KILL, key.toString());
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) {
            return;
        }
        BlockState state = event.getState();
        List<Quest> quests = QuestLog.get(player);
        boolean changed = false;
        for (Quest quest : quests) {
            if (quest.type == QuestType.MINE && !quest.isComplete() && blockMatches(state, quest.target)) {
                quest.have++;
                changed = true;
                notifyProgress(player, quest);
            }
        }
        if (changed) {
            QuestLog.save(player, quests);
        }
    }

    @SubscribeEvent
    public static void onFish(ItemFishedEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            advance(player, QuestType.FISH, "");
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        QuestLog.copy(event.getOriginal(), event.getEntity());
    }

    private static boolean blockMatches(BlockState state, String target) {
        if (target.startsWith("#")) {
            TagKey<Block> tag = TagKey.create(Registries.BLOCK, new ResourceLocation(target.substring(1)));
            return state.is(tag);
        }
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        return key != null && key.toString().equals(target);
    }

    /** Suma 1 a todas las misiones de ese tipo y objetivo. */
    private static void advance(ServerPlayer player, QuestType type, String target) {
        List<Quest> quests = QuestLog.get(player);
        boolean changed = false;
        for (Quest quest : quests) {
            if (quest.type == type && !quest.isComplete() && quest.target.equals(target)) {
                quest.have++;
                changed = true;
                notifyProgress(player, quest);
            }
        }
        if (changed) {
            QuestLog.save(player, quests);
        }
    }

    private static void notifyProgress(ServerPlayer player, Quest quest) {
        if (quest.isComplete()) {
            player.displayClientMessage(Component.translatable("quest.aventureros.ready", quest.giverName())
                    .withStyle(ChatFormatting.GREEN), true);
            player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                    SoundSource.PLAYERS, 0.6F, 1.5F);
        } else {
            player.displayClientMessage(Component.translatable("quest.aventureros.progress", quest.describe(),
                    quest.have, quest.need).withStyle(ChatFormatting.YELLOW), true);
        }
    }

    // ----------------------------------------------------------- Comandos

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("aventureros")
                .then(Commands.literal("misiones").executes(QuestEvents::listQuests))
                .then(Commands.literal("abandonar").executes(QuestEvents::abandon)));
    }

    private static int listQuests(CommandContext<CommandSourceStack> context) {
        if (!(context.getSource().getEntity() instanceof Player player)) {
            return 0;
        }
        List<Quest> quests = QuestLog.get(player);
        if (quests.isEmpty()) {
            context.getSource().sendSuccess(() -> Component.translatable("quest.aventureros.none"), false);
            return 1;
        }
        context.getSource().sendSuccess(() -> Component.translatable("quest.aventureros.log_title",
                quests.size(), QuestLog.MAX_ACTIVE).withStyle(ChatFormatting.GOLD), false);
        for (Quest quest : quests) {
            Component line = Component.translatable("quest.aventureros.log_entry", quest.giverName(),
                    quest.describeWithProgress(), quest.describeRewards());
            context.getSource().sendSuccess(() -> line, false);
        }
        return quests.size();
    }

    private static int abandon(CommandContext<CommandSourceStack> context) {
        if (!(context.getSource().getEntity() instanceof Player player)) {
            return 0;
        }
        QuestLog.clear(player);
        context.getSource().sendSuccess(() -> Component.translatable("quest.aventureros.abandoned"), false);
        return 1;
    }
}
