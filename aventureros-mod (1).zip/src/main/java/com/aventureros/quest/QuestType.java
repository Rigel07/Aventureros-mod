package com.aventureros.quest;

/** Tipos de mision. */
public enum QuestType {
    /** Traer objetos al aventurero. */
    FETCH,
    /** Derrotar un tipo de mob. */
    KILL,
    /** Picar bloques (un bloque o una etiqueta de bloques). */
    MINE,
    /** Pescar. */
    FISH
}
