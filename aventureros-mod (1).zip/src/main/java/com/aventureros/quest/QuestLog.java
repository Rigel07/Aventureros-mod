package com.aventureros.quest;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

/** Diario de misiones del jugador (se guarda en sus datos persistentes y sobrevive a la muerte). */
public final class QuestLog {
    public static final int MAX_ACTIVE = 3;
    private static final String KEY = "aventureros_quests";

    private QuestLog() {}

    private static CompoundTag root(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(Player.PERSISTED_NBT_TAG, Tag.TAG_COMPOUND)) {
            data.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        }
        return data.getCompound(Player.PERSISTED_NBT_TAG);
    }

    public static List<Quest> get(Player player) {
        List<Quest> quests = new ArrayList<>();
        ListTag list = root(player).getList(KEY, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            quests.add(Quest.fromNbt(list.getCompound(i)));
        }
        return quests;
    }

    public static void save(Player player, List<Quest> quests) {
        ListTag list = new ListTag();
        for (Quest quest : quests) {
            list.add(quest.toNbt());
        }
        root(player).put(KEY, list);
    }

    @Nullable
    public static Quest find(Player player, UUID giver) {
        for (Quest quest : get(player)) {
            if (quest.giver.equals(giver)) {
                return quest;
            }
        }
        return null;
    }

    public static boolean add(Player player, Quest quest) {
        List<Quest> quests = get(player);
        if (quests.size() >= MAX_ACTIVE) {
            return false;
        }
        quests.add(quest);
        save(player, quests);
        return true;
    }

    public static void remove(Player player, UUID giver) {
        List<Quest> quests = get(player);
        quests.removeIf(quest -> quest.giver.equals(giver));
        save(player, quests);
    }

    public static void clear(Player player) {
        save(player, new ArrayList<>());
    }

    /** Copia el diario al jugador nuevo tras morir. */
    public static void copy(Player from, Player to) {
        save(to, get(from));
    }
}
