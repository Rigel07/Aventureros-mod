package com.aventureros.client;

import com.aventureros.entity.AdventurerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class AdventurerRenderer extends MobRenderer<AdventurerEntity, AdventurerModel<AdventurerEntity>> {
    public AdventurerRenderer(EntityRendererProvider.Context context) {
        super(context, new AdventurerModel<>(context.bakeLayer(AdventurerModel.LAYER_LOCATION)), 0.35F);
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(AdventurerEntity entity) {
        return entity.getAdventurerClass().texture(entity.getVariant());
    }

    /** Cada aventurero tiene un tamano ligeramente distinto. */
    @Override
    protected void scale(AdventurerEntity entity, PoseStack poseStack, float partialTick) {
        float size = entity.getSizeScale();
        poseStack.scale(size, size, size);
    }
}
