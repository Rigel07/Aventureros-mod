package com.aventureros.client;

import com.aventureros.AventurerosMod;
import com.aventureros.entity.AdventurerClass;
import com.aventureros.entity.AdventurerClass.Parts;
import com.aventureros.entity.AdventurerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/** Modelo chibi del aventurero con sombreros y accesorios que se activan segun la clase. Textura 64x160. */
public class AdventurerModel<T extends AdventurerEntity> extends EntityModel<T> implements ArmedModel {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(AventurerosMod.MODID, "aventurero"), "main");

    private final ModelPart root;
    private final ModelPart model;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    // Accesorios opcionales
    private final ModelPart cape, backpack, brim, crown, cone2, cone3, helmet, plume, feather, lamp, cap, visor,
            hood, halo, headband, knot, lens, chef;

    public AdventurerModel(ModelPart root) {
        this.root = root;
        this.model = root.getChild("model");
        this.head = this.model.getChild("head");
        this.rightArm = this.model.getChild("right_arm");
        this.leftArm = this.model.getChild("left_arm");
        this.rightLeg = this.model.getChild("right_leg");
        this.leftLeg = this.model.getChild("left_leg");
        ModelPart body = this.model.getChild("body");
        this.cape = body.getChild("cape");
        this.backpack = body.getChild("backpack");
        this.brim = this.head.getChild("brim");
        this.crown = this.head.getChild("crown");
        this.cone2 = this.head.getChild("cone2");
        this.cone3 = this.head.getChild("cone3");
        this.helmet = this.head.getChild("helmet");
        this.plume = this.head.getChild("plume");
        this.feather = this.head.getChild("feather");
        this.lamp = this.head.getChild("lamp");
        this.cap = this.head.getChild("cap");
        this.visor = this.head.getChild("visor");
        this.hood = this.head.getChild("hood");
        this.halo = this.head.getChild("halo");
        this.headband = this.head.getChild("headband");
        this.knot = this.head.getChild("knot");
        this.lens = this.head.getChild("lens");
        this.chef = this.head.getChild("chef");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition model = root.addOrReplaceChild("model", CubeListBuilder.create(), PartPose.ZERO);

        PartDefinition head = model.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 12.0F, 0.0F));
        PartDefinition body = model.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(16, 16).addBox(-3.0F, -7.0F, -2.0F, 6.0F, 7.0F, 4.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));
        model.addOrReplaceChild("right_arm", CubeListBuilder.create()
                        .texOffs(40, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(-4.0F, 13.0F, 0.0F));
        model.addOrReplaceChild("left_arm", CubeListBuilder.create()
                        .texOffs(40, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(4.0F, 13.0F, 0.0F));
        model.addOrReplaceChild("right_leg", CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(-1.5F, 19.0F, 0.0F));
        model.addOrReplaceChild("left_leg", CubeListBuilder.create()
                        .texOffs(0, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(1.5F, 19.0F, 0.0F));

        // ---- Accesorios del cuerpo ----
        body.addOrReplaceChild("cape", CubeListBuilder.create()
                .texOffs(0, 32).addBox(-4.0F, -7.0F, 2.0F, 8.0F, 9.0F, 1.0F), PartPose.ZERO);
        body.addOrReplaceChild("backpack", CubeListBuilder.create()
                .texOffs(20, 32).addBox(-3.0F, -6.0F, 2.0F, 6.0F, 7.0F, 3.0F), PartPose.ZERO);

        // ---- Sombreros y accesorios de la cabeza ----
        head.addOrReplaceChild("brim", CubeListBuilder.create()
                .texOffs(0, 44).addBox(-5.5F, -8.4F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.ZERO);
        head.addOrReplaceChild("crown", CubeListBuilder.create()
                .texOffs(0, 57).addBox(-4.0F, -11.2F, -4.0F, 8.0F, 3.0F, 8.0F), PartPose.ZERO);
        head.addOrReplaceChild("cone2", CubeListBuilder.create()
                .texOffs(34, 57).addBox(-3.0F, -14.2F, -3.0F, 6.0F, 3.0F, 6.0F), PartPose.ZERO);
        head.addOrReplaceChild("cone3", CubeListBuilder.create()
                .texOffs(46, 44).addBox(-1.5F, -17.2F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("helmet", CubeListBuilder.create()
                .texOffs(0, 70).addBox(-4.5F, -9.0F, -4.5F, 9.0F, 5.0F, 9.0F), PartPose.ZERO);
        head.addOrReplaceChild("plume", CubeListBuilder.create()
                .texOffs(38, 70).addBox(-0.5F, -13.0F, -2.0F, 1.0F, 4.0F, 4.0F), PartPose.ZERO);
        head.addOrReplaceChild("feather", CubeListBuilder.create()
                .texOffs(50, 70).addBox(3.2F, -12.0F, -1.5F, 1.0F, 5.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("lamp", CubeListBuilder.create()
                .texOffs(38, 79).addBox(-1.5F, -8.0F, -6.5F, 3.0F, 3.0F, 2.0F), PartPose.ZERO);
        head.addOrReplaceChild("cap", CubeListBuilder.create()
                .texOffs(0, 86).addBox(-4.5F, -9.0F, -4.5F, 9.0F, 2.0F, 9.0F), PartPose.ZERO);
        head.addOrReplaceChild("visor", CubeListBuilder.create()
                .texOffs(38, 86).addBox(-3.5F, -8.0F, -7.5F, 7.0F, 1.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("hood", CubeListBuilder.create()
                .texOffs(0, 98).addBox(-4.5F, -9.0F, -1.5F, 9.0F, 9.0F, 6.0F), PartPose.ZERO);
        head.addOrReplaceChild("halo", CubeListBuilder.create()
                .texOffs(34, 98).addBox(-3.0F, -12.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.ZERO);
        head.addOrReplaceChild("headband", CubeListBuilder.create()
                .texOffs(0, 86).addBox(-4.5F, -6.0F, -4.5F, 9.0F, 2.0F, 9.0F), PartPose.ZERO);
        head.addOrReplaceChild("knot", CubeListBuilder.create()
                .texOffs(34, 106).addBox(-1.0F, -6.0F, 4.5F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        head.addOrReplaceChild("lens", CubeListBuilder.create()
                .texOffs(46, 106).addBox(-3.5F, -8.2F, -4.7F, 3.0F, 2.0F, 1.0F)
                .addBox(0.5F, -8.2F, -4.7F, 3.0F, 2.0F, 1.0F), PartPose.ZERO);
        head.addOrReplaceChild("chef", CubeListBuilder.create()
                .texOffs(0, 114).addBox(-4.5F, -16.0F, -4.5F, 9.0F, 8.0F, 9.0F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 160);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        AdventurerClass cls = entity.getAdventurerClass();
        this.cape.visible = cls.has(Parts.CAPE);
        this.backpack.visible = cls.has(Parts.BACKPACK);
        this.brim.visible = cls.has(Parts.BRIM);
        this.crown.visible = cls.has(Parts.CROWN);
        this.cone2.visible = cls.has(Parts.CONE2);
        this.cone3.visible = cls.has(Parts.CONE3);
        this.helmet.visible = cls.has(Parts.HELMET);
        this.plume.visible = cls.has(Parts.PLUME);
        this.feather.visible = cls.has(Parts.FEATHER);
        this.lamp.visible = cls.has(Parts.LAMP);
        this.cap.visible = cls.has(Parts.CAP);
        this.visor.visible = cls.has(Parts.VISOR);
        this.hood.visible = cls.has(Parts.HOOD);
        this.halo.visible = cls.has(Parts.HALO);
        this.headband.visible = cls.has(Parts.HEADBAND);
        this.knot.visible = cls.has(Parts.KNOT);
        this.lens.visible = cls.has(Parts.LENS);
        this.chef.visible = cls.has(Parts.CHEF);

        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);

        float swing = limbSwing * 0.6662F;
        this.rightArm.xRot = Mth.cos(swing + (float) Math.PI) * 1.2F * limbSwingAmount;
        this.leftArm.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
        this.rightLeg.xRot = Mth.cos(swing) * 1.4F * limbSwingAmount;
        this.leftLeg.xRot = Mth.cos(swing + (float) Math.PI) * 1.4F * limbSwingAmount;

        this.rightArm.zRot = 0.06F + Mth.sin(ageInTicks * 0.067F) * 0.05F;
        this.leftArm.zRot = -0.06F - Mth.sin(ageInTicks * 0.067F) * 0.05F;

        // Brazo con objeto un poco levantado
        if (!entity.getMainHandItem().isEmpty()) {
            this.rightArm.xRot -= 0.35F;
        }
        if (!entity.getOffhandItem().isEmpty()) {
            this.leftArm.xRot -= 0.25F;
        }
        // Capa y mochila se mecen un poquito al andar
        this.cape.xRot = 0.05F + Math.abs(limbSwingAmount) * 0.25F;
    }

    @Override
    public void translateToHand(HumanoidArm arm, PoseStack poseStack) {
        (arm == HumanoidArm.LEFT ? this.leftArm : this.rightArm).translateAndRotate(poseStack);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
