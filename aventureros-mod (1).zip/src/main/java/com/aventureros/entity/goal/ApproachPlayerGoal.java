package com.aventureros.entity.goal;

import com.aventureros.entity.AdventurerEntity;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

/** El aventurero con mision pendiente se acerca a ti, se queda a un par de bloques y te mira. */
public class ApproachPlayerGoal extends Goal {
    private final AdventurerEntity adventurer;
    private Player target;
    private int ticks;

    public ApproachPlayerGoal(AdventurerEntity adventurer) {
        this.adventurer = adventurer;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!this.adventurer.wantsToTalk() || this.adventurer.getApproachCooldown() > 0) {
            return false;
        }
        Player player = this.adventurer.level().getNearestPlayer(this.adventurer, 12.0D);
        if (player == null || player.isSpectator() || !this.adventurer.hasLineOfSight(player)) {
            return false;
        }
        this.target = player;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return this.target != null
                && this.target.isAlive()
                && !this.target.isSpectator()
                && this.adventurer.wantsToTalk()
                && this.adventurer.distanceToSqr(this.target) < 196.0D
                && this.ticks < 400;
    }

    @Override
    public void start() {
        this.ticks = 0;
    }

    @Override
    public void stop() {
        this.adventurer.getNavigation().stop();
        this.adventurer.setApproachCooldown(600);
        this.target = null;
    }

    // Sin @Override a proposito: compila aunque el metodo no exista en la version.
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        this.ticks++;
        this.adventurer.getLookControl().setLookAt(this.target, 30.0F, 30.0F);
        if (this.adventurer.distanceToSqr(this.target) > 9.0D) {
            if (this.adventurer.getNavigation().isDone()) {
                this.adventurer.getNavigation().moveTo(this.target, 1.0D);
            }
        } else {
            this.adventurer.getNavigation().stop();
        }
    }
}
