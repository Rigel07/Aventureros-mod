package com.aventureros.entity;

import com.aventureros.AventurerosMod;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** Las 14 clases de aventurero: cada una con su ropa, sombrero, objetos y misiones. */
public enum AdventurerClass {
    KNIGHT("knight", Parts.HELMET | Parts.PLUME, () -> Items.IRON_SWORD, () -> Items.SHIELD),
    WIZARD("wizard", Parts.BRIM | Parts.CROWN | Parts.CONE2 | Parts.CONE3, () -> Items.BLAZE_ROD, null),
    ARCHER("archer", Parts.CAP | Parts.VISOR | Parts.FEATHER | Parts.BACKPACK, () -> Items.BOW, null),
    ROGUE("rogue", Parts.HOOD | Parts.CAP | Parts.CAPE, () -> Items.IRON_SWORD, null),
    CLERIC("cleric", Parts.HALO, () -> Items.BOOK, null),
    BARD("bard", Parts.CAP | Parts.VISOR | Parts.FEATHER, () -> Items.GOAT_HORN, null),
    EXPLORER("explorer", Parts.BRIM | Parts.CROWN | Parts.BACKPACK, () -> Items.SPYGLASS, () -> Items.MAP),
    MINER("miner", Parts.HELMET | Parts.LAMP | Parts.BACKPACK, () -> Items.IRON_PICKAXE, () -> Items.TORCH),
    FISHER("fisher", Parts.BRIM | Parts.CROWN, () -> Items.FISHING_ROD, null),
    PIRATE("pirate", Parts.HEADBAND | Parts.KNOT, () -> Items.GOLDEN_SWORD, null),
    NINJA("ninja", Parts.HEADBAND | Parts.KNOT | Parts.CAPE, () -> Items.IRON_SWORD, null),
    ALCHEMIST("alchemist", Parts.HEADBAND | Parts.LENS | Parts.BACKPACK, () -> Items.GLASS_BOTTLE, null),
    CHEF("chef", Parts.CHEF, () -> Items.COOKED_CHICKEN, null),
    FARMER("farmer", Parts.BRIM | Parts.CROWN, () -> Items.IRON_HOE, null);

    public static final int VARIANTS = 4;

    /** Piezas opcionales del modelo (sombreros y accesorios), como banderas. */
    public static final class Parts {
        public static final int CAPE = 1;
        public static final int BACKPACK = 1 << 1;
        public static final int BRIM = 1 << 2;
        public static final int CROWN = 1 << 3;
        public static final int CONE2 = 1 << 4;
        public static final int CONE3 = 1 << 5;
        public static final int HELMET = 1 << 6;
        public static final int PLUME = 1 << 7;
        public static final int FEATHER = 1 << 8;
        public static final int LAMP = 1 << 9;
        public static final int CAP = 1 << 10;
        public static final int VISOR = 1 << 11;
        public static final int HOOD = 1 << 12;
        public static final int HALO = 1 << 13;
        public static final int HEADBAND = 1 << 14;
        public static final int KNOT = 1 << 15;
        public static final int LENS = 1 << 16;
        public static final int CHEF = 1 << 17;

        private Parts() {}
    }

    private final String id;
    private final int parts;
    private final Supplier<Item> mainHand;
    @Nullable
    private final Supplier<Item> offHand;
    private final ResourceLocation[] textures = new ResourceLocation[VARIANTS];

    AdventurerClass(String id, int parts, Supplier<Item> mainHand, @Nullable Supplier<Item> offHand) {
        this.id = id;
        this.parts = parts;
        this.mainHand = mainHand;
        this.offHand = offHand;
        for (int i = 0; i < VARIANTS; i++) {
            this.textures[i] = new ResourceLocation(AventurerosMod.MODID, "textures/entity/adventurer_" + id + "_" + i + ".png");
        }
    }

    public String id() { return this.id; }
    public boolean has(int part) { return (this.parts & part) != 0; }
    public Item mainHand() { return this.mainHand.get(); }
    @Nullable
    public Item offHand() { return this.offHand == null ? null : this.offHand.get(); }

    public ResourceLocation texture(int variant) {
        return this.textures[Math.floorMod(variant, VARIANTS)];
    }

    public static AdventurerClass byIndex(int index) {
        AdventurerClass[] all = values();
        return all[Math.floorMod(index, all.length)];
    }
}
