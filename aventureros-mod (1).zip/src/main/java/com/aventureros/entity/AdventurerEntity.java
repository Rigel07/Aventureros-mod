package com.aventureros.entity;

import com.aventureros.entity.goal.ApproachPlayerGoal;
import com.aventureros.quest.Quest;
import com.aventureros.quest.QuestFactory;
import com.aventureros.quest.QuestLog;
import com.aventureros.quest.QuestType;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Aventurero: un viajero cute y pacifico que busca aventuras por todo el mundo.
 * Si te acercas, te llama; al hablarle te da una mision y, al completarla, una recompensa.
 */
public class AdventurerEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_CLASS =
            SynchedEntityData.defineId(AdventurerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(AdventurerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_SCALE =
            SynchedEntityData.defineId(AdventurerEntity.class, EntityDataSerializers.FLOAT);

    private static final String[] NAMES_M = {"Pipo", "Bruno", "Tico", "Nico", "Lalo", "Teo", "Milo", "Rufo", "Dani", "Ciro", "Oli", "Fito"};
    private static final String[] NAMES_F = {"Luna", "Mimi", "Lola", "Nora", "Pepa", "Rosi", "Lia", "Kiki", "Tina", "Bea", "Coco", "Mica"};

    private static final int STATE_AVAILABLE = 0;
    private static final int STATE_ACTIVE = 1;
    private static final int STATE_LEAVING = 2;

    private int state = STATE_AVAILABLE;
    @Nullable
    private UUID questPlayer;
    @Nullable
    private Quest quest;
    private int lifeTicks = 0;
    private int leaveTicks = 0;
    private int noticeCooldown = 0;
    private int approachCooldown = 0;

    public AdventurerEntity(EntityType<? extends AdventurerEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.26D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    /** Pueden aparecer en cualquier sitio con suelo firme (superficie, cuevas, Nether...). */
    public static boolean checkAdventurerSpawnRules(EntityType<AdventurerEntity> type, ServerLevelAccessor level,
                                                    MobSpawnType reason, BlockPos pos, RandomSource random) {
        return Mob.checkMobSpawnRules(type, level, reason, pos, random)
                && level.getFluidState(pos).isEmpty();
    }

    // ------------------------------------------------------------ Aspecto

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_CLASS, 0);
        this.entityData.define(DATA_VARIANT, 0);
        this.entityData.define(DATA_SCALE, 1.0F);
    }

    public AdventurerClass getAdventurerClass() {
        return AdventurerClass.byIndex(this.entityData.get(DATA_CLASS));
    }

    public int getVariant() {
        return this.entityData.get(DATA_VARIANT);
    }

    public float getSizeScale() {
        return this.entityData.get(DATA_SCALE);
    }

    public void setAdventurerClass(AdventurerClass cls) {
        this.entityData.set(DATA_CLASS, cls.ordinal());
    }

    // --------------------------------------------------------------- Creacion

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        RandomSource random = this.getRandom();
        if (!this.presetClass) {
            this.setAdventurerClass(AdventurerClass.byIndex(random.nextInt(AdventurerClass.values().length)));
        }
        this.entityData.set(DATA_VARIANT, random.nextInt(AdventurerClass.VARIANTS));
        this.entityData.set(DATA_SCALE, 0.9F + random.nextFloat() * 0.2F);
        this.giveName(random);
        this.equipForClass();
        this.quest = QuestFactory.generate(this.getAdventurerClass(), random, this.getUUID(), this.getName());
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    /** Lo usa el huevo de una clase concreta para que no se sobrescriba al aparecer. */
    private boolean presetClass = false;

    public void presetClass(AdventurerClass cls) {
        this.setAdventurerClass(cls);
        this.presetClass = true;
    }

    private void giveName(RandomSource random) {
        boolean female = random.nextBoolean();
        String[] names = female ? NAMES_F : NAMES_M;
        String first = names[random.nextInt(names.length)];
        MutableComponent name = Component.literal(first + " ")
                .append(Component.translatable("class.aventureros." + this.getAdventurerClass().id() + (female ? ".f" : ".m")));
        this.setCustomName(name);
        this.setCustomNameVisible(false);
    }

    private void equipForClass() {
        AdventurerClass cls = this.getAdventurerClass();
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(cls.mainHand()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        if (cls.offHand() != null) {
            this.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(cls.offHand()));
            this.setDropChance(EquipmentSlot.OFFHAND, 0.0F);
        }
    }

    // ----------------------------------------------------------------- IA

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new PanicGoal(this, 1.5D));
        this.goalSelector.addGoal(3, new ApproachPlayerGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.9D, 0.02F));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    public boolean wantsToTalk() {
        return this.state == STATE_AVAILABLE;
    }

    public int getApproachCooldown() { return this.approachCooldown; }
    public void setApproachCooldown(int ticks) { this.approachCooldown = ticks; }

    // --------------------------------------------------------- Conversacion

    private void speak(ServerPlayer player, Component text) {
        MutableComponent line = Component.empty()
                .append(Component.literal("[").withStyle(ChatFormatting.GOLD))
                .append(this.getName().copy().withStyle(ChatFormatting.GOLD))
                .append(Component.literal("] ").withStyle(ChatFormatting.GOLD))
                .append(text.copy().withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(line);
    }

    private Component line(String key) {
        return Component.translatable("dialog.aventureros." + this.getAdventurerClass().id() + "." + key);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            this.talk(serverPlayer);
        }
        return InteractionResult.CONSUME;
    }

    private void talk(ServerPlayer player) {
        this.getLookControl().setLookAt(player, 30.0F, 30.0F);

        if (this.state == STATE_LEAVING) {
            this.speak(player, this.line("bye"));
            return;
        }

        if (this.state == STATE_ACTIVE) {
            if (this.questPlayer == null || !this.questPlayer.equals(player.getUUID())) {
                this.speak(player, Component.translatable("dialog.aventureros.busy"));
                return;
            }
            Quest mine = QuestLog.find(player, this.getUUID());
            if (mine == null) {
                // El jugador abandono la mision: vuelve a estar disponible
                this.state = STATE_AVAILABLE;
                this.questPlayer = null;
            } else {
                this.checkProgress(player, mine);
                return;
            }
        }

        this.offerQuest(player);
    }

    private void offerQuest(ServerPlayer player) {
        if (this.quest == null) {
            this.quest = QuestFactory.generate(this.getAdventurerClass(), this.getRandom(), this.getUUID(), this.getName());
        }
        this.speak(player, this.line("greet"));
        if (QuestLog.get(player).size() >= QuestLog.MAX_ACTIVE) {
            this.speak(player, Component.translatable("dialog.aventureros.too_many"));
            return;
        }
        Quest accepted = this.quest.copy();
        accepted.have = 0;
        QuestLog.add(player, accepted);
        this.state = STATE_ACTIVE;
        this.questPlayer = player.getUUID();

        this.speak(player, this.line("ask"));
        player.sendSystemMessage(Component.translatable("quest.aventureros.mission",
                accepted.describe()).withStyle(ChatFormatting.YELLOW));
        player.sendSystemMessage(Component.translatable("quest.aventureros.reward",
                accepted.describeRewards()).withStyle(ChatFormatting.GREEN));
        this.level().playSound(null, this.blockPosition(), SoundEvents.VILLAGER_YES, SoundSource.NEUTRAL, 1.0F, 1.4F);
        this.puff(ParticleTypes.NOTE);
    }

    private void checkProgress(ServerPlayer player, Quest mine) {
        if (mine.type == QuestType.FETCH) {
            if (countItems(player, mine.target) >= mine.need) {
                removeItems(player, mine.target, mine.need);
                this.complete(player, mine);
            } else {
                this.speak(player, this.line("remind"));
                player.sendSystemMessage(Component.translatable("quest.aventureros.mission",
                        mine.describe()).withStyle(ChatFormatting.YELLOW));
            }
            return;
        }
        if (mine.isComplete()) {
            this.complete(player, mine);
        } else {
            this.speak(player, this.line("remind"));
            player.sendSystemMessage(Component.translatable("quest.aventureros.mission",
                    mine.describeWithProgress()).withStyle(ChatFormatting.YELLOW));
        }
    }

    private void complete(ServerPlayer player, Quest quest) {
        this.speak(player, this.line("thanks"));
        for (ItemStack reward : quest.rewards) {
            ItemStack give = reward.copy();
            if (!player.getInventory().add(give)) {
                player.drop(give, false);
            }
        }
        if (quest.xp > 0 && this.level() instanceof ServerLevel server) {
            ExperienceOrb.award(server, player.position(), quest.xp);
        }
        QuestLog.remove(player, this.getUUID());
        player.sendSystemMessage(Component.translatable("quest.aventureros.completed").withStyle(ChatFormatting.GREEN));
        this.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 1.2F);
        this.puff(ParticleTypes.HAPPY_VILLAGER);
        this.state = STATE_LEAVING;
        this.leaveTicks = 240;
        this.questPlayer = null;
    }

    private static int countItems(Player player, String itemId) {
        int total = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (matches(stack, itemId)) {
                total += stack.getCount();
            }
        }
        return total;
    }

    private static void removeItems(Player player, String itemId, int amount) {
        int left = amount;
        for (ItemStack stack : player.getInventory().items) {
            if (left <= 0) {
                break;
            }
            if (matches(stack, itemId)) {
                int take = Math.min(left, stack.getCount());
                stack.shrink(take);
                left -= take;
            }
        }
    }

    private static boolean matches(ItemStack stack, String itemId) {
        if (stack.isEmpty()) {
            return false;
        }
        net.minecraft.resources.ResourceLocation key =
                net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(stack.getItem());
        return key != null && key.toString().equals(itemId);
    }

    private void puff(net.minecraft.core.particles.SimpleParticleType particle) {
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(particle, this.getX(), this.getY() + 1.6D, this.getZ(), 6, 0.4D, 0.3D, 0.4D, 0.02D);
        }
    }

    // ------------------------------------------------------------------ Tick

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        this.lifeTicks++;
        if (this.noticeCooldown > 0) {
            this.noticeCooldown--;
        }
        if (this.approachCooldown > 0) {
            this.approachCooldown--;
        }

        // Te llama cuando te acercas
        if (this.state == STATE_AVAILABLE && this.noticeCooldown == 0 && this.tickCount % 10 == 0) {
            Player nearby = this.level().getNearestPlayer(this, 6.0D);
            if (nearby instanceof ServerPlayer player && !player.isSpectator() && this.hasLineOfSight(player)) {
                this.noticeCooldown = 1200;
                this.speak(player, this.line("notice"));
                this.getLookControl().setLookAt(player, 30.0F, 30.0F);
                this.level().playSound(null, this.blockPosition(), SoundEvents.VILLAGER_YES, SoundSource.NEUTRAL, 1.0F, 1.5F);
                this.puff(ParticleTypes.NOTE);
                this.jumpFromGround();
            }
        }

        // Se va en busca de nuevas aventuras
        if (this.state == STATE_LEAVING) {
            this.leaveTicks--;
            if (this.tickCount % 40 == 0 && this.getNavigation().isDone()) {
                double angle = this.getRandom().nextDouble() * Math.PI * 2.0D;
                this.getNavigation().moveTo(this.getX() + Math.cos(angle) * 16.0D, this.getY(),
                        this.getZ() + Math.sin(angle) * 16.0D, 1.3D);
            }
            if (this.leaveTicks <= 0) {
                if (this.level() instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 0.8D, this.getZ(),
                            20, 0.4D, 0.5D, 0.4D, 0.05D);
                }
                this.discard();
            }
            return;
        }

        // No llenan el mundo: tras unos dias sin que nadie los atienda, siguen su camino
        int maxLife = this.state == STATE_ACTIVE ? 168000 : 72000;
        if (this.lifeTicks > maxLife && this.level().getNearestPlayer(this, 24.0D) == null) {
            this.discard();
        }
    }

    // --------------------------------------------------------------- Datos

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("AdvClass", this.entityData.get(DATA_CLASS));
        tag.putInt("AdvVariant", this.getVariant());
        tag.putFloat("AdvScale", this.getSizeScale());
        tag.putInt("AdvState", this.state);
        tag.putInt("AdvLife", this.lifeTicks);
        tag.putInt("AdvLeave", this.leaveTicks);
        if (this.questPlayer != null) {
            tag.putUUID("AdvQuestPlayer", this.questPlayer);
        }
        if (this.quest != null) {
            tag.put("AdvQuest", this.quest.toNbt());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("AdvClass")) {
            this.entityData.set(DATA_CLASS, tag.getInt("AdvClass"));
        }
        this.entityData.set(DATA_VARIANT, tag.getInt("AdvVariant"));
        if (tag.contains("AdvScale")) {
            this.entityData.set(DATA_SCALE, Mth.clamp(tag.getFloat("AdvScale"), 0.8F, 1.2F));
        }
        this.state = tag.getInt("AdvState");
        this.lifeTicks = tag.getInt("AdvLife");
        this.leaveTicks = tag.getInt("AdvLeave");
        if (tag.hasUUID("AdvQuestPlayer")) {
            this.questPlayer = tag.getUUID("AdvQuestPlayer");
        }
        if (tag.contains("AdvQuest")) {
            this.quest = Quest.fromNbt(tag.getCompound("AdvQuest"));
        }
    }

    // ---------------------------------------------------------------- Sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.GRASS_STEP, 0.15F, 1.2F);
    }

    @Override
    public int getMaxSpawnClusterSize() {
        return 1;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
