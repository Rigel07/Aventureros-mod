# Aventureros (Forge 1.20.1)

Viajeros cute y pacíficos que recorren el mundo buscando aventuras. Aparecen al azar en **cualquier sitio** (superficie, cuevas, Nether y End), son muy distintos entre sí, y **te dan misiones con recompensa**.

## Cómo funciona
1. Si te acercas, el aventurero te **llama**, te mira y se acerca a ti.
2. **Clic derecho** para hablarle: te cuenta su misión y la recompensa, y la misión pasa a tu diario (máximo 3 a la vez).
3. Cumple el objetivo y **vuelve a hablarle** (clic derecho): te da la recompensa y se va en busca de otra aventura.

Si una misión no la quieres: `/aventureros abandonar`. Para ver las que tienes: `/aventureros misiones`.

## Tipos de misión
- **Traer objetos** (se entregan al hablarle).
- **Derrotar mobs** (zombis, esqueletos, arañas, creepers, brujas, ahogados, saqueadores...).
- **Picar bloques** (piedra, troncos, menas de carbón, hierro, cobre u oro).
- **Pescar**.
Las misiones difíciles dan mejores recompensas (esmeraldas, diamantes, libros encantados, discos, tótems...).

## Las 14 clases (muy distintas)
Caballero, Mago, Arquero, Pícaro, Clérigo, Bardo, Explorador, Minero, Pescador, Pirata, Ninja, Alquimista, Chef y Granjero.
Cada una tiene su ropa, sombrero y objetos, su manera de hablar, sus propias misiones y su propio tipo de recompensas.
Además hay 4 apariencias por clase (piel, pelo y ojos), un tamaño ligeramente distinto en cada uno y un nombre propio.

## Detalles
- Pacíficos: si los golpeas, huyen. No luchan.
- Se marchan solos si nadie los atiende en unos 3 días de juego, así que no llenan el mundo.
- Hay huevos de aventurero para cada clase (y uno al azar) en la pestaña creativa.

## Compilar con GitHub (sin descomprimir)
1. Sube el zip del mod tal cual a la raíz de un repositorio.
2. Crea a mano `.github/workflows/build.yml` con el archivo que acompaña al zip (la carpeta `.github` es oculta y no se sube arrastrando).
3. Actions > último workflow > Artifacts > `aventureros-jar`.
